/*
 * tcpclient.h
 *
 *  Created on: 21-Apr-2022
 *      Author: controllerstech
 */

#ifndef INC_TCPCLIENT_H_
#define INC_TCPCLIENT_H_


void tcpclient_init (void);


#endif /* INC_TCPCLIENT_H_ */
