/*
 * tcpserver.h
 *
 *  Created on: Apr 20, 2022
 *      Author: controllerstech
 */

#ifndef INC_TCPSERVER_H_
#define INC_TCPSERVER_H_

void tcpserver_init (void);

#endif /* INC_TCPSERVER_H_ */
